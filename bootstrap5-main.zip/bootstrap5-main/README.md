# bootstrap5
Aquesta és una plantilla web en català amb menú desplegable, icones Font Awesome diferenciades, mode clar i fosc, i disseny responsiu per mòbil i ordinador utilitzant Bootstrap 5.3.8.

index.html pel cus 2025-2026
